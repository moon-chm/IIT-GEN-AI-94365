import requests
import pandas
print("Requests version:", requests.__version__)
print("Pandas version:", pandas.__version__)