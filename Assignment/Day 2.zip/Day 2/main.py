import math_module
num1=int(input("Enter length of rectangle: "))
num2=int(input("Enter breadth of rectangle: "))
print('Area of rectangle:',math_module.cal_area(num1,num2))
print('Perimeter of rectangle:',math_module.cal_perimeter(num1,num2))