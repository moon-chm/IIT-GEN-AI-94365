def cal_area(a,b):
    area = a * b
    return area
def cal_perimeter(a,b):
    perimeter = 2 * (a + b)
    return perimeter
